# AIGallery
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on the phone (USB debugging) or Build > Build APK.
3. In the app: AI tab > gear icon > enter API keys (console.anthropic.com for Claude, clipdrop.co/apis for Clipdrop).
Replace the icon: put your own images in app/src/main/res (Android Studio: right-click res > New > Image Asset).
