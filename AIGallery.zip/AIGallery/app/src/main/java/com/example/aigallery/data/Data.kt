package com.example.aigallery.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore.Images.Media
import org.json.JSONArray
import org.json.JSONObject

data class Photo(val id: Long, val uri: Uri, val date: Long, val album: String)
data class PhotoMeta(val caption: String, val tags: List<String>, val faces: Int)

object MediaRepo {
    fun load(ctx: Context): List<Photo> {
        val out = mutableListOf<Photo>()
        val proj = arrayOf(Media._ID, Media.DATE_TAKEN, Media.DATE_ADDED, Media.BUCKET_DISPLAY_NAME)
        ctx.contentResolver.query(Media.EXTERNAL_CONTENT_URI, proj, null, null, "${Media.DATE_ADDED} DESC")?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val taken = c.getLong(1)
                val added = c.getLong(2) * 1000
                out += Photo(id, ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, id),
                    if (taken > 0) taken else added, c.getString(3) ?: "")
            }
        }
        return out
    }
}

/** Keys + AI metadata, stored locally on the phone. */
class AiStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("ai", Context.MODE_PRIVATE)
    var claudeKey: String
        get() = sp.getString("claude", "") ?: ""
        set(v) { sp.edit().putString("claude", v.trim()).apply() }
    var clipdropKey: String
        get() = sp.getString("clipdrop", "") ?: ""
        set(v) { sp.edit().putString("clipdrop", v.trim()).apply() }

    fun getMeta(id: Long): PhotoMeta? = sp.getString("meta_$id", null)?.let {
        val j = JSONObject(it); val a = j.getJSONArray("tags")
        PhotoMeta(j.getString("caption"), List(a.length()) { i -> a.getString(i) }, j.optInt("faces"))
    }
    fun putMeta(id: Long, m: PhotoMeta) {
        val j = JSONObject().put("caption", m.caption).put("tags", JSONArray(m.tags)).put("faces", m.faces)
        sp.edit().putString("meta_$id", j.toString()).apply()
    }
    fun indexedCount() = sp.all.keys.count { it.startsWith("meta_") }
}
