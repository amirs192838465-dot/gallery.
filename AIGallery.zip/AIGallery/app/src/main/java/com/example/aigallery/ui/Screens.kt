package com.example.aigallery.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PhotoAlbum
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.aigallery.ai.AiService
import com.example.aigallery.data.AiStore
import com.example.aigallery.data.MediaRepo
import com.example.aigallery.data.Photo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

enum class EditMode(val label: String) { BG("حذف پس‌زمینه"), OBJ("حذف شیء"), ENH("بهبود کیفیت") }

@Composable
fun GalleryApp() {
    val ctx = LocalContext.current
    val store = remember { AiStore(ctx) }
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
    else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var photos by remember { mutableStateOf(emptyList<Photo>()) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(perm) }
    LaunchedEffect(granted, reload) { if (granted) photos = withContext(Dispatchers.IO) { MediaRepo.load(ctx) } }

    var viewer by remember { mutableStateOf<Photo?>(null) }
    var editor by remember { mutableStateOf<Pair<Photo, EditMode>?>(null) }
    var settings by remember { mutableStateOf(false) }
    BackHandler(settings || editor != null || viewer != null) {
        when { settings -> settings = false; editor != null -> editor = null; else -> viewer = null }
    }
    when {
        settings -> SettingsScreen(store) { settings = false }
        editor != null -> EditorScreen(editor!!.first, editor!!.second, store, { editor = null }, { reload++ })
        viewer != null -> ViewerScreen(viewer!!, store, { viewer = null }) { editor = viewer!! to it }
        else -> HomeScreen(photos, store, { viewer = it }, { settings = true })
    }
}

@Composable
fun HomeScreen(photos: List<Photo>, store: AiStore, onOpen: (Photo) -> Unit, onSettings: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var album by remember { mutableStateOf<String?>(null) }
    BackHandler(album != null) { album = null }
    val items = listOf("عکس‌ها" to Icons.Default.PhotoLibrary, "آلبوم‌ها" to Icons.Default.PhotoAlbum,
        "هوش مصنوعی" to Icons.Default.AutoAwesome)
    Scaffold(bottomBar = {
        NavigationBar {
            items.forEachIndexed { i, (label, icon) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i; album = null },
                    icon = { Icon(icon, null) }, label = { Text(label) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> PhotoGrid(photos, onOpen)
                1 -> if (album == null) AlbumList(photos) { album = it }
                     else PhotoGrid(photos.filter { it.album == album }, onOpen)
                else -> AiTab(photos, store, onOpen, onSettings)
            }
        }
    }
}

@Composable
fun PhotoGrid(photos: List<Photo>, onOpen: (Photo) -> Unit) {
    val fmt = remember { DateFormat.getDateInstance(DateFormat.LONG) }
    val groups = remember(photos) { photos.groupBy { fmt.format(Date(it.date)) } }
    LazyVerticalGrid(GridCells.Fixed(4), horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)) {
        groups.forEach { (day, list) ->
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(day, Modifier.padding(12.dp, 10.dp), style = MaterialTheme.typography.labelLarge)
            }
            items(list, key = { it.id }) { p ->
                AsyncImage(p.uri, null, Modifier.aspectRatio(1f).clickable { onOpen(p) }, contentScale = ContentScale.Crop)
            }
        }
    }
}

@Composable
fun AlbumList(photos: List<Photo>, onPick: (String) -> Unit) {
    val albums = remember(photos) { photos.groupBy { it.album } }
    LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(albums.entries.toList(), key = { it.key }) { (name, list) ->
            Column(Modifier.clickable { onPick(name) }) {
                AsyncImage(list.first().uri, null, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop)
                Text(name.ifBlank { "—" }, Modifier.padding(top = 4.dp))
                Text("${list.size}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun AiTab(photos: List<Photo>, store: AiStore, onOpen: (Photo) -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Photo>?>(null) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var indexed by remember { mutableIntStateOf(store.indexedCount()) }

    fun matches(p: Photo, kws: List<String>): Boolean {
        val m = store.getMeta(p.id) ?: return false
        val t = (m.caption + " " + m.tags.joinToString(" ")).lowercase()
        return kws.any { t.contains(it.lowercase()) }
    }
    fun search() {
        if (q.isBlank()) { results = null; return }
        scope.launch {
            busy = true; status = "در حال جستجو…"
            try {
                val kw = AiService.expandQuery(store.claudeKey, q)
                results = photos.filter { matches(it, kw) }
                status = "${results!!.size} نتیجه"
            } catch (e: Exception) { status = e.message ?: "خطا" }
            busy = false
        }
    }
    fun index() {
        scope.launch {
            busy = true
            val todo = photos.filter { store.getMeta(it.id) == null }.take(50)
            for ((i, p) in todo.withIndex()) {
                status = "تحلیل ${i + 1} از ${todo.size}"
                try {
                    store.putMeta(p.id, AiService.analyze(ctx, store.claudeKey, p.uri))
                    indexed = store.indexedCount()
                } catch (e: Exception) { status = e.message ?: "خطا"; busy = false; return@launch }
            }
            status = "تمام شد"; busy = false
        }
    }

    Column {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(q, { q = it }, Modifier.weight(1f), singleLine = true,
                placeholder = { Text("جستجو: مثلاً «غروب کنار دریا»") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { search() }))
            IconButton(onSettings) { Icon(Icons.Default.Settings, null) }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val chips = listOf("افراد" to "people", "غذا" to "food", "سند" to "document",
                "اسکرین‌شات" to "screenshot", "طبیعت" to "nature", "سلفی" to "selfie")
            items(chips) { (fa, en) ->
                AssistChip(onClick = { q = fa; results = photos.filter { matches(it, listOf(fa, en)) } },
                    label = { Text(fa) })
            }
        }
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { index() }, enabled = !busy) { Text("تحلیل عکس‌های جدید (۵۰ تا)") }
            Spacer(Modifier.width(8.dp))
            Text("$indexed/${photos.size}", style = MaterialTheme.typography.bodySmall)
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (status.isNotBlank()) Text(status, Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.bodySmall)
        results?.let { PhotoGrid(it, onOpen) }
    }
}

@Composable
fun ViewerScreen(p: Photo, store: AiStore, onBack: () -> Unit, onEdit: (EditMode) -> Unit) {
    val meta = remember(p) { store.getMeta(p.id) }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AsyncImage(p.uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        IconButton(onBack, Modifier.align(Alignment.TopStart).padding(8.dp)) {
            Icon(Icons.Default.ArrowBack, null, tint = Color.White)
        }
        Column(Modifier.align(Alignment.BottomCenter).padding(12.dp)) {
            meta?.let { Text(it.caption, color = Color.White, modifier = Modifier.padding(bottom = 8.dp)) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EditMode.values().forEach { m -> FilledTonalButton({ onEdit(m) }) { Text(m.label, fontSize = 12.sp) } }
            }
        }
    }
}

private fun buildMask(w: Int, h: Int, strokes: List<List<Offset>>): Bitmap {
    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(b); c.drawColor(android.graphics.Color.BLACK)
    val paint = android.graphics.Paint().apply {
        color = android.graphics.Color.WHITE; style = android.graphics.Paint.Style.STROKE
        strokeWidth = w * 0.06f; strokeCap = android.graphics.Paint.Cap.ROUND
        strokeJoin = android.graphics.Paint.Join.ROUND; isAntiAlias = false
    }
    strokes.forEach { s ->
        if (s.size == 1) c.drawPoint(s[0].x * w, s[0].y * h, paint)
        else {
            val path = android.graphics.Path()
            s.forEachIndexed { i, o -> if (i == 0) path.moveTo(o.x * w, o.y * h) else path.lineTo(o.x * w, o.y * h) }
            c.drawPath(path, paint)
        }
    }
    return b
}

@Composable
fun EditorScreen(photo: Photo, mode: EditMode, store: AiStore, onBack: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var src by remember { mutableStateOf<Bitmap?>(null) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var current by remember { mutableStateOf(emptyList<Offset>()) }
    LaunchedEffect(photo) {
        src = withContext(Dispatchers.IO) { AiService.loadBitmap(ctx, photo.uri, if (mode == EditMode.ENH) 1024 else 2048) }
    }
    fun run() {
        scope.launch {
            busy = true; err = null
            try {
                val s = src!!; val key = store.clipdropKey
                result = when (mode) {
                    EditMode.BG -> AiService.removeBackground(key, s)
                    EditMode.ENH -> AiService.enhance(key, s)
                    EditMode.OBJ -> {
                        require(strokes.isNotEmpty()) { "روی شیء مورد نظر انگشت بکشید" }
                        AiService.cleanup(key, s, buildMask(s.width, s.height, strokes))
                    }
                }
            } catch (e: Exception) { err = e.message }
            busy = false
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text(mode.label, style = MaterialTheme.typography.titleMedium)
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            val shown = result ?: src
            if (shown != null) {
                Box(Modifier.aspectRatio(shown.width.toFloat() / shown.height).background(Color.LightGray)) {
                    Image(shown.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                    if (mode == EditMode.OBJ && result == null) {
                        Canvas(Modifier.fillMaxSize().pointerInput(Unit) {
                            fun n(o: Offset) = Offset(o.x / size.width, o.y / size.height)
                            detectDragGestures(
                                onDragStart = { current = listOf(n(it)) },
                                onDrag = { ch, _ -> current = current + n(ch.position) },
                                onDragEnd = { strokes.add(current); current = emptyList() })
                        }) {
                            (strokes + listOf(current)).filter { it.isNotEmpty() }.forEach { s ->
                                val path = Path()
                                s.forEachIndexed { i, o -> if (i == 0) path.moveTo(o.x * size.width, o.y * size.height)
                                    else path.lineTo(o.x * size.width, o.y * size.height) }
                                drawPath(path, Color.Red.copy(alpha = 0.5f),
                                    style = Stroke(size.width * 0.06f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                            }
                        }
                    }
                }
            } else CircularProgressIndicator()
            if (busy) CircularProgressIndicator()
        }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (mode == EditMode.OBJ && result == null)
                TextButton({ if (strokes.isNotEmpty()) strokes.removeLast() }) { Text("بازگرداندن") }
            Button({ run() }, enabled = !busy && src != null) { Text("اجرا") }
            if (result != null) {
                Button({
                    AiService.save(ctx, result!!, mode == EditMode.BG)
                    Toast.makeText(ctx, "ذخیره شد", Toast.LENGTH_SHORT).show(); onSaved()
                }) { Text("ذخیره") }
                TextButton({ result = null }) { Text("اصل") }
            }
        }
    }
}

@Composable
fun SettingsScreen(store: AiStore, onBack: () -> Unit) {
    var claude by remember { mutableStateOf(store.claudeKey) }
    var clip by remember { mutableStateOf(store.clipdropKey) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        IconButton(onBack) { Icon(Icons.Default.ArrowBack, null) }
        Text("کلیدهای API", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(claude, { claude = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("Claude API key (جستجو و دسته‌بندی)") }, visualTransformation = PasswordVisualTransformation())
        OutlinedTextField(clip, { clip = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("Clipdrop API key (ویرایش تصویر)") }, visualTransformation = PasswordVisualTransformation())
        Button({ store.claudeKey = claude; store.clipdropKey = clip; onBack() }) { Text("ذخیره") }
    }
}
