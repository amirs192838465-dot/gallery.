package com.example.aigallery.ai

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.MediaStore
import android.util.Base64
import com.example.aigallery.data.PhotoMeta
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object AiService {
    // Claude model used for understanding photos (cheap + fast, supports images).
    const val CLAUDE_MODEL = "claude-haiku-5-5"
    private val http = OkHttpClient.Builder().callTimeout(120, TimeUnit.SECONDS).build()

    fun loadBitmap(ctx: Context, uri: Uri, max: Int): Bitmap =
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { dec, info, _ ->
            val s = max.toFloat() / maxOf(info.size.width, info.size.height)
            if (s < 1f) dec.setTargetSize((info.size.width * s).toInt(), (info.size.height * s).toInt())
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }

    private fun Bitmap.bytes(png: Boolean = false, q: Int = 85): ByteArray {
        val o = ByteArrayOutputStream()
        compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, q, o)
        return o.toByteArray()
    }

    private fun claude(key: String, content: JSONArray, maxTokens: Int = 600): String {
        require(key.isNotBlank()) { "کلید API کلود را در تنظیمات وارد کنید" }
        val body = JSONObject().put("model", CLAUDE_MODEL).put("max_tokens", maxTokens)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", key).header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("Claude ${r.code}: $txt")
            return JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
        }
    }

    private fun text(t: String) = JSONObject().put("type", "text").put("text", t)

    /** Caption + tags (Persian & English) via Claude vision, plus on-device face count via ML Kit. */
    suspend fun analyze(ctx: Context, key: String, uri: Uri): PhotoMeta = withContext(Dispatchers.IO) {
        val bmp = loadBitmap(ctx, uri, 768)
        val img = JSONObject().put("type", "image").put("source", JSONObject()
            .put("type", "base64").put("media_type", "image/jpeg")
            .put("data", Base64.encodeToString(bmp.bytes(), Base64.NO_WRAP)))
        val out = claude(key, JSONArray().put(img).put(text(
            "Describe this photo for a searchable gallery. Reply ONLY with JSON: " +
            "{\"caption\":\"one Persian sentence\",\"tags\":[10-15 short tags, mixing Persian and English: " +
            "objects, scene, activity, colors, category such as selfie/food/document/screenshot/nature/pet]}. " +
            "Do not identify real people by name.")))
        val j = JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
        val a = j.getJSONArray("tags")
        val tags = MutableList(a.length()) { a.getString(it) }
        val faces = runCatching {
            FaceDetection.getClient().process(InputImage.fromBitmap(bmp, 0)).await().size
        }.getOrDefault(0)
        if (faces > 0) { tags += "افراد"; tags += "people"; tags += "face" }
        PhotoMeta(j.optString("caption"), tags, faces)
    }

    /** Smart search: Claude expands the query to Persian+English keywords, matched locally. */
    suspend fun expandQuery(key: String, q: String): List<String> = withContext(Dispatchers.IO) {
        val out = claude(key, JSONArray().put(text(
            "A user searches their photo gallery for: \"$q\". Reply ONLY with a JSON array of 8-15 short " +
            "keywords/synonyms in Persian and English that photo tags might contain.")), 300)
        val a = JSONArray(out.substring(out.indexOf('['), out.lastIndexOf(']') + 1))
        List(a.length()) { a.getString(it) } + q
    }

    // ---- Image editing via Clipdrop (Stability AI) API ----
    private fun clipdrop(key: String, path: String, build: MultipartBody.Builder.() -> Unit): Bitmap {
        require(key.isNotBlank()) { "کلید API کلیپ‌دراپ را در تنظیمات وارد کنید" }
        val mb = MultipartBody.Builder().setType(MultipartBody.FORM).apply(build)
        val req = Request.Builder().url("https://clipdrop-api.co/$path").header("x-api-key", key).post(mb.build()).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Clipdrop ${r.code}: ${r.body?.string()}")
            return BitmapFactory.decodeStream(r.body!!.byteStream())
        }
    }
    private fun MultipartBody.Builder.file(name: String, b: Bitmap, png: Boolean) =
        addFormDataPart(name, if (png) "$name.png" else "$name.jpg",
            b.bytes(png).toRequestBody((if (png) "image/png" else "image/jpeg").toMediaType()))

    suspend fun removeBackground(key: String, src: Bitmap) = withContext(Dispatchers.IO) {
        clipdrop(key, "remove-background/v1") { file("image_file", src, false) }
    }
    suspend fun cleanup(key: String, src: Bitmap, mask: Bitmap) = withContext(Dispatchers.IO) {
        clipdrop(key, "cleanup/v1") { file("image_file", src, false); file("mask_file", mask, true) }
    }
    /** Upscaling input must be <= 1024px; output is 2x. */
    suspend fun enhance(key: String, src: Bitmap) = withContext(Dispatchers.IO) {
        clipdrop(key, "image-upscaling/v1/upscale") {
            file("image_file", src, false)
            addFormDataPart("target_width", (src.width * 2).toString())
            addFormDataPart("target_height", (src.height * 2).toString())
        }
    }

    fun save(ctx: Context, bmp: Bitmap, png: Boolean): Uri? {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "AI_${System.currentTimeMillis()}")
            put(MediaStore.Images.Media.MIME_TYPE, if (png) "image/png" else "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AIGallery")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(bmp.bytes(png, 95)) }
        return uri
    }
}
